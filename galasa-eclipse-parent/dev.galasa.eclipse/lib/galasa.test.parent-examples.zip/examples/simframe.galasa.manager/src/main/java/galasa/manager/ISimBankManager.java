package galasa.manager;

public interface ISimBankManager {
    
}