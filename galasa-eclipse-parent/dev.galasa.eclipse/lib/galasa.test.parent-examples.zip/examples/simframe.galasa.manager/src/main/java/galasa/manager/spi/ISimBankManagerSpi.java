package galasa.manager.spi;

import galasa.manager.ISimBankManager;

public interface ISimBankManagerSpi extends ISimBankManager {
    
}