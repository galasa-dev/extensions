package galasa.manager;

public enum AccountType {
	HighValue,
	LowValue,
	InDebt
}
